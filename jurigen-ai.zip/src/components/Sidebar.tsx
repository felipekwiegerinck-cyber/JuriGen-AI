import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useProjects } from '../contexts/ProjectContext';
import { useNavigate, useLocation } from 'react-router-dom';
import { Scale, Plus, FileText, LogOut, User as UserIcon, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '../lib/utils';

export default function Sidebar() {
  const { user, isGuest, logout } = useAuth();
  const { projects, createProject, deleteProject, currentProject } = useProjects();
  const navigate = useNavigate();
  const location = useLocation();

  const handleCreateProject = async () => {
    try {
      const id = await createProject();
      navigate(`/project/${id}`);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (window.confirm('Tem certeza que deseja excluir este projeto?')) {
      await deleteProject(id);
      if (currentProject?.id === id) {
        navigate('/');
      }
    }
  };

  return (
    <div className="w-64 bg-slate-900 h-screen flex flex-col text-slate-300">
      <div className="p-4 flex items-center gap-3 border-b border-slate-800 cursor-pointer" onClick={() => navigate('/')}>
        <div className="bg-blue-600 p-2 rounded-lg">
          <Scale className="w-6 h-6 text-white" />
        </div>
        <h1 className="text-xl font-bold text-white">JuriGen AI</h1>
      </div>

      <div className="p-4">
        <button
          onClick={handleCreateProject}
          className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors font-medium"
        >
          <Plus className="w-5 h-5" />
          Nova Peça
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
        <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3 px-2">
          Meus Projetos
        </h2>
        
        {projects.length === 0 ? (
          <p className="text-sm text-slate-500 px-2 italic">Nenhum projeto criado.</p>
        ) : (
          projects.map((project) => (
            <div
              key={project.id}
              onClick={() => navigate(`/project/${project.id}`)}
              className={cn(
                "group flex items-center justify-between p-2 rounded-md cursor-pointer transition-colors",
                location.pathname === `/project/${project.id}` 
                  ? "bg-slate-800 text-white" 
                  : "hover:bg-slate-800/50"
              )}
            >
              <div className="flex items-center gap-3 overflow-hidden">
                <FileText className="w-4 h-4 shrink-0 text-slate-400" />
                <div className="truncate">
                  <p className="text-sm font-medium truncate">{project.title}</p>
                  <p className="text-xs text-slate-500 truncate">
                    {format(project.updatedAt, "dd 'de' MMM, HH:mm", { locale: ptBR })}
                  </p>
                </div>
              </div>
              <button
                onClick={(e) => handleDelete(e, project.id)}
                className="opacity-0 group-hover:opacity-100 p-1 hover:bg-slate-700 rounded text-slate-400 hover:text-red-400 transition-all"
                title="Excluir"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>

      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center shrink-0">
            {user?.photoURL ? (
              <img src={user.photoURL} alt="User" className="w-8 h-8 rounded-full" referrerPolicy="no-referrer" />
            ) : (
              <UserIcon className="w-5 h-5 text-slate-400" />
            )}
          </div>
          <div className="truncate">
            <p className="text-sm font-medium text-white truncate">
              {isGuest ? 'Modo Visitante' : user?.displayName || 'Usuário'}
            </p>
            <p className="text-xs text-slate-500 truncate">
              {isGuest ? 'Não salvo na nuvem' : user?.email}
            </p>
          </div>
        </div>
        
        <button
          onClick={() => {
            logout();
            navigate('/login');
          }}
          className="w-full flex items-center gap-2 text-sm text-slate-400 hover:text-white hover:bg-slate-800 p-2 rounded-md transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Sair
        </button>
      </div>
    </div>
  );
}
