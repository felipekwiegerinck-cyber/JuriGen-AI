import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Send, Bot, User, Loader2, FileText, Check, Copy } from 'lucide-react';
import { cn } from '../lib/utils';
import { Message } from '../types';
import { v4 as uuidv4 } from 'uuid';
import * as pdfjsLib from 'pdfjs-dist';

// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

interface ChatProps {
  projectContent: string;
  onApplyChanges: (newContent: string) => void;
}

export default function Chat({ projectContent, onApplyChanges }: ChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'model',
      content: 'Olá! Sou seu assistente jurídico. Posso ajudar a redigir, revisar ou formatar sua peça processual. Você também pode anexar documentos (PDF/Word) para eu analisar.'
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<{name: string, text: string}[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const extractTextFromPDF = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';
    
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(' ');
      fullText += pageText + '\n';
    }
    
    return fullText;
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsLoading(true);
    try {
      const newFiles = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        let text = '';
        
        if (file.type === 'application/pdf') {
          text = await extractTextFromPDF(file);
        } else {
          // Fallback for text files or simple parsing
          text = await file.text();
        }
        
        newFiles.push({ name: file.name, text });
      }
      
      setAttachedFiles(prev => [...prev, ...newFiles]);
    } catch (error) {
      console.error("Error parsing file", error);
      alert("Erro ao ler o arquivo. Certifique-se de que é um PDF ou arquivo de texto válido.");
    } finally {
      setIsLoading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const removeFile = (index: number) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSend = async () => {
    if (!input.trim() && attachedFiles.length === 0) return;

    const userMessageContent = input;
    const currentFiles = [...attachedFiles];
    
    const newUserMessage: Message = {
      id: uuidv4(),
      role: 'user',
      content: userMessageContent + (currentFiles.length > 0 ? `\n\n[Anexos: ${currentFiles.map(f => f.name).join(', ')}]` : '')
    };

    setMessages(prev => [...prev, newUserMessage]);
    setInput('');
    setAttachedFiles([]); // Clear attachments after sending
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      let systemInstruction = `Você é um assistente jurídico especializado em direito brasileiro. 
Seu objetivo é ajudar a redigir, revisar e estruturar peças processuais (Petições Iniciais, Contestações, Recursos, etc).
Use linguagem formal, técnica e jurídica adequada.

DIRETRIZES IMPORTANTES:
1. NUNCA se recuse a gerar uma peça processual por falta de documentos ou informações.
2. Se o usuário pedir para gerar uma peça e não fornecer documentos ou fatos específicos, CRIE a peça usando fatos genéricos, nomes fictícios (ex: FULANO DE TAL, EMPRESA X) e espaços reservados (ex: [Inserir data], [Inserir valor]) para que o usuário possa preencher depois.
3. Sempre que o usuário pedir para gerar ou alterar a peça, forneça o texto formatado em HTML (usando <h1>, <h2>, <p>, <strong>, <ul>, etc) para que possa ser inserido diretamente no editor de texto.
4. Coloque o conteúdo HTML dentro de um bloco de código markdown com a tag \`\`\`html.

Conteúdo atual do documento do usuário (para contexto):
"""
${projectContent}
"""`;

      let promptText = userMessageContent;
      
      if (currentFiles.length > 0) {
        promptText += `\n\nDocumentos anexados para análise:\n`;
        currentFiles.forEach(file => {
          promptText += `\n--- Início do documento: ${file.name} ---\n${file.text}\n--- Fim do documento: ${file.name} ---\n`;
        });
      }

      const modelMessageId = uuidv4();
      setMessages(prev => [...prev, {
        id: modelMessageId,
        role: 'model',
        content: ''
      }]);

      const responseStream = await ai.models.generateContentStream({
        model: 'gemini-3-flash-preview',
        contents: promptText,
        config: {
          systemInstruction,
          temperature: 0.4, // Lower temperature for more formal/deterministic legal text
        }
      });

      let fullText = '';
      let isFirstChunk = true;

      for await (const chunk of responseStream) {
        if (isFirstChunk) {
          setIsLoading(false);
          isFirstChunk = false;
        }
        if (chunk.text) {
          fullText += chunk.text;
          setMessages(prev => prev.map(msg => 
            msg.id === modelMessageId ? { ...msg, content: fullText } : msg
          ));
        }
      }

      if (!fullText) {
        setMessages(prev => prev.map(msg => 
          msg.id === modelMessageId ? { ...msg, content: 'Desculpe, não consegui gerar uma resposta.' } : msg
        ));
      }
    } catch (error: any) {
      console.error("Error calling Gemini AI", error);
      setMessages(prev => [...prev, {
        id: uuidv4(),
        role: 'model',
        content: `Ocorreu um erro ao processar sua solicitação: ${error.message || 'Verifique sua conexão ou tente novamente.'}`
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const extractHtmlAndApply = (content: string) => {
    const htmlMatch = content.match(/```html\n([\s\S]*?)\n```/);
    if (htmlMatch && htmlMatch[1]) {
      onApplyChanges(htmlMatch[1]);
    } else {
      // If no markdown block, try to apply the whole text if it looks like HTML, otherwise wrap in paragraphs
      if (content.includes('<p>') || content.includes('<h1>')) {
        onApplyChanges(content);
      } else {
        const formatted = content.split('\n\n').map(p => `<p>${p}</p>`).join('');
        onApplyChanges(formatted);
      }
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50">
      <div className="p-4 border-b border-slate-200 bg-white shadow-sm z-10">
        <h2 className="font-semibold text-slate-800 flex items-center gap-2">
          <Bot className="w-5 h-5 text-blue-600" />
          Assistente IA
        </h2>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={cn(
              "flex gap-3 max-w-[90%]",
              msg.role === 'user' ? "ml-auto flex-row-reverse" : ""
            )}
          >
            <div className={cn(
              "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
              msg.role === 'user' ? "bg-slate-800 text-white" : "bg-blue-100 text-blue-600"
            )}>
              {msg.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
            </div>
            
            <div className={cn(
              "p-3 rounded-lg text-sm shadow-sm",
              msg.role === 'user' 
                ? "bg-slate-800 text-white rounded-tr-none" 
                : "bg-white border border-slate-200 text-slate-700 rounded-tl-none"
            )}>
              <div className="whitespace-pre-wrap">{msg.content}</div>
              
              {msg.role === 'model' && (msg.content.includes('```html') || msg.content.length > 200) && (
                <div className="mt-3 pt-3 border-t border-slate-100 flex justify-end">
                  <button
                    onClick={() => extractHtmlAndApply(msg.content)}
                    className="flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 py-1 px-2 rounded transition-colors"
                  >
                    <Check className="w-3 h-3" />
                    Aplicar ao Documento
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex gap-3 max-w-[90%]">
            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
              <Bot className="w-5 h-5" />
            </div>
            <div className="p-3 rounded-lg bg-white border border-slate-200 text-slate-700 rounded-tl-none flex items-center gap-2 shadow-sm">
              <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
              <span className="text-sm text-slate-500">Analisando...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-white border-t border-slate-200">
        {attachedFiles.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {attachedFiles.map((file, idx) => (
              <div key={idx} className="flex items-center gap-1 bg-blue-50 text-blue-700 text-xs py-1 px-2 rounded border border-blue-100">
                <FileText className="w-3 h-3" />
                <span className="truncate max-w-[150px]">{file.name}</span>
                <button onClick={() => removeFile(idx)} className="ml-1 hover:text-blue-900 font-bold">&times;</button>
              </div>
            ))}
          </div>
        )}
        
        <div className="flex items-end gap-2">
          <div className="flex-1 relative">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Descreva a peça ou peça alterações..."
              className="w-full border border-slate-300 rounded-lg pl-3 pr-10 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none max-h-32 min-h-[44px]"
              rows={input.split('\n').length > 1 ? Math.min(input.split('\n').length, 4) : 1}
            />
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileUpload} 
              className="hidden" 
              multiple 
              accept=".pdf,.txt,.doc,.docx"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="absolute right-2 bottom-2 p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
              title="Anexar Documento"
            >
              <FileText className="w-4 h-4" />
            </button>
          </div>
          <button
            onClick={handleSend}
            disabled={isLoading || (!input.trim() && attachedFiles.length === 0)}
            className="bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed shrink-0 h-[44px] w-[44px] flex items-center justify-center"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
