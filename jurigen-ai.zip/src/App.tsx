/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ProjectProvider } from './contexts/ProjectContext';
import Login from './pages/Login';
import Home from './pages/Home';
import ProjectEditor from './pages/ProjectEditor';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isAuthReady, isGuest } = useAuth();
  
  if (!isAuthReady) {
    return <div className="min-h-screen flex items-center justify-center">Carregando...</div>;
  }

  if (!user && !isGuest) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

export default function App() {
  return (
    <AuthProvider>
      <ProjectProvider>
        <Router>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<ProtectedRoute><Home /></ProtectedRoute>} />
            <Route path="/project/:id" element={<ProtectedRoute><ProjectEditor /></ProtectedRoute>} />
          </Routes>
        </Router>
      </ProjectProvider>
    </AuthProvider>
  );
}
