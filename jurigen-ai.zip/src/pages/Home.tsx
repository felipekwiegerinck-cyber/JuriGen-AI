import React from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { useProjects } from '../contexts/ProjectContext';
import { useNavigate } from 'react-router-dom';
import { Plus, FileText, Scale } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Home() {
  const { user, isGuest } = useAuth();
  const { projects, createProject } = useProjects();
  const navigate = useNavigate();

  const handleCreateProject = async () => {
    try {
      const id = await createProject();
      navigate(`/project/${id}`);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Layout>
      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-5xl mx-auto">
          <header className="mb-12">
            <h1 className="text-3xl font-bold text-slate-900 mb-2">
              Bem-vindo ao JuriGen AI
            </h1>
            <p className="text-slate-600">
              {isGuest 
                ? 'Você está no modo visitante. Seus projetos não serão salvos na nuvem.' 
                : `Olá, ${user?.displayName || 'Doutor(a)'}. O que vamos redigir hoje?`}
            </p>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div 
              onClick={handleCreateProject}
              className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md hover:border-blue-300 cursor-pointer transition-all group flex flex-col items-center justify-center text-center h-48"
            >
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Plus className="w-6 h-6" />
              </div>
              <h3 className="font-semibold text-slate-900">Nova Peça Processual</h3>
              <p className="text-sm text-slate-500 mt-1">Comece um documento do zero com ajuda da IA</p>
            </div>
            
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm opacity-60 cursor-not-allowed flex flex-col items-center justify-center text-center h-48">
              <div className="w-12 h-12 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mb-4">
                <Scale className="w-6 h-6" />
              </div>
              <h3 className="font-semibold text-slate-900">Modelos Prontos</h3>
              <p className="text-sm text-slate-500 mt-1">Em breve: biblioteca de modelos</p>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold text-slate-900 mb-6 flex items-center gap-2">
              <FileText className="w-5 h-5 text-slate-500" />
              Projetos Recentes
            </h2>
            
            {projects.length === 0 ? (
              <div className="bg-white rounded-xl border border-slate-200 border-dashed p-12 text-center">
                <FileText className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-900 mb-1">Nenhum projeto ainda</h3>
                <p className="text-slate-500 mb-6">Crie sua primeira peça processual para começar.</p>
                <button
                  onClick={handleCreateProject}
                  className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors font-medium"
                >
                  <Plus className="w-5 h-5" />
                  Criar Novo Projeto
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
                <table className="min-w-full divide-y divide-slate-200">
                  <thead className="bg-slate-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        Nome do Projeto
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        Última Modificação
                      </th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">
                        Ação
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-slate-200">
                    {projects.map((project) => (
                      <tr 
                        key={project.id} 
                        className="hover:bg-slate-50 cursor-pointer transition-colors"
                        onClick={() => navigate(`/project/${project.id}`)}
                      >
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <FileText className="w-5 h-5 text-blue-500 mr-3" />
                            <div className="text-sm font-medium text-slate-900">{project.title}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-slate-500">
                            {format(project.updatedAt, "dd 'de' MMMM 'de' yyyy, HH:mm", { locale: ptBR })}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate(`/project/${project.id}`);
                            }}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            Abrir
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
