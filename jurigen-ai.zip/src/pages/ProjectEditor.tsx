import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import { useProjects } from '../contexts/ProjectContext';
import Editor from '../components/Editor';
import Chat from '../components/Chat';
import { FileText, Download, Save, ArrowLeft, Loader2 } from 'lucide-react';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import { saveAs } from 'file-saver';

export default function ProjectEditor() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { projects, updateProject, isLoading } = useProjects();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const project = projects.find(p => p.id === id);

  useEffect(() => {
    if (project) {
      setTitle(project.title);
      setContent(project.content);
    }
  }, [project]);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      </Layout>
    );
  }

  if (!project && !isLoading) {
    return (
      <Layout>
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
          <FileText className="w-16 h-16 text-slate-300 mb-4" />
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Projeto não encontrado</h2>
          <p className="text-slate-500 mb-6">O projeto que você está procurando não existe ou foi excluído.</p>
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors font-medium"
          >
            <ArrowLeft className="w-5 h-5" />
            Voltar para o Início
          </button>
        </div>
      </Layout>
    );
  }

  const handleSave = async () => {
    if (!id) return;
    setIsSaving(true);
    try {
      await updateProject(id, { title, content });
    } catch (error) {
      console.error("Error saving project", error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleExportWord = async () => {
    // Simple HTML to DOCX conversion (for a real app, you'd want a more robust parser)
    // Here we just strip HTML tags and create paragraphs for simplicity
    const plainText = content.replace(/<[^>]+>/g, '\n').split('\n').filter(p => p.trim() !== '');
    
    const doc = new Document({
      sections: [{
        properties: {},
        children: plainText.map(text => new Paragraph({
          children: [new TextRun(text)],
          spacing: { after: 200 }
        }))
      }]
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, `${title || 'documento'}.docx`);
  };

  return (
    <Layout>
      <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4 flex-1">
          <button 
            onClick={() => navigate('/')}
            className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors"
            title="Voltar"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onBlur={handleSave}
            className="text-lg font-semibold text-slate-900 bg-transparent border-none focus:ring-0 p-0 w-full max-w-md placeholder:text-slate-400"
            placeholder="Nome do Projeto"
          />
        </div>
        
        <div className="flex items-center gap-3">
          <span className="text-xs text-slate-500 flex items-center gap-1">
            {isSaving ? (
              <><Loader2 className="w-3 h-3 animate-spin" /> Salvando...</>
            ) : (
              <><Save className="w-3 h-3" /> Salvo</>
            )}
          </span>
          <button
            onClick={handleExportWord}
            className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 py-1.5 px-3 rounded-md transition-colors text-sm font-medium border border-slate-200"
          >
            <Download className="w-4 h-4" />
            Exportar Word
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Editor Area */}
        <div className="flex-1 overflow-y-auto bg-slate-100 p-8 flex justify-center">
          <div className="w-full max-w-4xl bg-white shadow-sm border border-slate-200 min-h-full rounded-sm">
            <Editor content={content} onChange={(html) => {
              setContent(html);
              // Auto-save debounce could be added here
              if (id) updateProject(id, { content: html });
            }} />
          </div>
        </div>

        {/* Chat Area */}
        <div className="w-96 border-l border-slate-200 bg-white flex flex-col shrink-0">
          <Chat 
            projectContent={content} 
            onApplyChanges={(newContent) => {
              setContent(newContent);
              if (id) updateProject(id, { content: newContent });
            }} 
          />
        </div>
      </div>
    </Layout>
  );
}
