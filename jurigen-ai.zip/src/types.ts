export interface Project {
  id: string;
  userId: string | null; // null for guest
  title: string;
  content: string;
  createdAt: number;
  updatedAt: number;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
}
