import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { collection, doc, onSnapshot, setDoc, deleteDoc, serverTimestamp, query, where, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from './AuthContext';
import { Project } from '../types';
import { v4 as uuidv4 } from 'uuid';

interface ProjectContextType {
  projects: Project[];
  currentProject: Project | null;
  setCurrentProject: (project: Project | null) => void;
  createProject: (title?: string) => Promise<string>;
  updateProject: (id: string, updates: Partial<Project>) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  isLoading: boolean;
}

const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

export function ProjectProvider({ children }: { children: React.ReactNode }) {
  const { user, isGuest, isAuthReady } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Local state for guest mode
  const [guestProjects, setGuestProjects] = useState<Project[]>([]);

  useEffect(() => {
    if (!isAuthReady) return;

    if (isGuest) {
      setProjects(guestProjects);
      setIsLoading(false);
      return;
    }

    if (!user) {
      setProjects([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    const q = query(
      collection(db, 'projects'),
      where('userId', '==', user.uid),
      orderBy('updatedAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedProjects = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Project[];
      setProjects(fetchedProjects);
      setIsLoading(false);
      
      // Update current project if it changed
      if (currentProject) {
        const updatedCurrent = fetchedProjects.find(p => p.id === currentProject.id);
        if (updatedCurrent) {
          setCurrentProject(updatedCurrent);
        } else {
          setCurrentProject(null);
        }
      }
    }, (error) => {
      console.error("Error fetching projects:", error);
      setIsLoading(false);
    });

    return unsubscribe;
  }, [user, isGuest, isAuthReady, guestProjects]);

  const createProject = useCallback(async (title: string = 'Nova Peça Processual') => {
    const newId = uuidv4();
    const now = Date.now();
    const newProject: Project = {
      id: newId,
      userId: user ? user.uid : null,
      title,
      content: '',
      createdAt: now,
      updatedAt: now,
    };

    if (isGuest) {
      setGuestProjects(prev => [newProject, ...prev]);
      setCurrentProject(newProject);
      return newId;
    }

    if (user) {
      await setDoc(doc(db, 'projects', newId), newProject);
      setCurrentProject(newProject);
      return newId;
    }

    throw new Error('User not authenticated');
  }, [user, isGuest]);

  const updateProject = useCallback(async (id: string, updates: Partial<Project>) => {
    const now = Date.now();
    
    if (isGuest) {
      setGuestProjects(prev => prev.map(p => p.id === id ? { ...p, ...updates, updatedAt: now } : p));
      if (currentProject?.id === id) {
        setCurrentProject(prev => prev ? { ...prev, ...updates, updatedAt: now } : null);
      }
      return;
    }

    if (user) {
      // Optimistic update for current project
      if (currentProject?.id === id) {
        setCurrentProject(prev => prev ? { ...prev, ...updates, updatedAt: now } : null);
      }
      await setDoc(doc(db, 'projects', id), { ...updates, updatedAt: now }, { merge: true });
      return;
    }
  }, [user, isGuest, currentProject]);

  const deleteProject = useCallback(async (id: string) => {
    if (isGuest) {
      setGuestProjects(prev => prev.filter(p => p.id !== id));
      if (currentProject?.id === id) {
        setCurrentProject(null);
      }
      return;
    }

    if (user) {
      await deleteDoc(doc(db, 'projects', id));
      if (currentProject?.id === id) {
        setCurrentProject(null);
      }
      return;
    }
  }, [user, isGuest, currentProject]);

  return (
    <ProjectContext.Provider value={{ projects, currentProject, setCurrentProject, createProject, updateProject, deleteProject, isLoading }}>
      {children}
    </ProjectContext.Provider>
  );
}

export function useProjects() {
  const context = useContext(ProjectContext);
  if (context === undefined) {
    throw new Error('useProjects must be used within a ProjectProvider');
  }
  return context;
}
